import pandas as pd
import os
import re
from getpass import getuser
#from main import file_save_path_tickets
from typing import Literal
from Entities.apiXrm import ApiXrm
#from Entities.crenciais import Credential
import multiprocessing
from datetime import datetime
from filtrar_spam import SpamFilter, AlterTickets

if __name__ == "__main__":
    agora = datetime.now()
    multiprocessing.freeze_support()
    #filter = SpamFilter(file_save_path_tickets)
    api = AlterTickets()
    
    #filter.spam('List_ids')
    #print(filter.historico)